# AI Brain Graph for TopDown Engine

For an introducton to the tool, please visit the [documentation website](https://thebitcave.gitbook.io/ai-brain-extensions-docs/)

## Release Notes

See the [dedicated page](https://github.com/thebitcave/ai-brain-extensions-for-topdown-engine/releases).

## Credits

Logo icons by [fjstudio](https://www.flaticon.com/free-icon/binary_2214519) and [Freepik](https://www.flaticon.com/free-icon/centralized-structure_66069).
